package com.zenith_keyboard_fix.client;

import net.fabricmc.api.ClientModInitializer;

public class ZenithLauncherTastaturFixClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// This entrypoint is suitable for setting up client-specific logic, such as rendering.
	}
}